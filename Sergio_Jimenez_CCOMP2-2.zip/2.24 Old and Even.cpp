#include <iostream>
using namespace std;

int main() {
    int n;

    cout << "Colocar un integral: ";
    cin >> n;

    if ( n % 2 == 0)
        cout << n << "Is Even.";
    else
    cout << n << "Is Old";

    return 0 
}