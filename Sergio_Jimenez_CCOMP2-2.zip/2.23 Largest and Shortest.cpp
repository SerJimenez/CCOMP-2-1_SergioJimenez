#include<iostream>
using namespace std;
main()
{
    int a,b,c,d,e,max,min;
    cout<<"Escriba 5 integrales=";
    cin>>a>>b>>c>>d>>e;
    min=max=a;
    if(b<min)min=b;
    if(c<min)min=c;
    if(d<min)min=d;
    if(e<min)min=e;
    if(b>max)max=b;
    if(c>max)max=c;
    if(d>max)max=d;
    if(e>max)max=e;
    cout<<"El numero mas largo es: "<<max<<endl;
    cout<<"El numero mas corto es: "<<min<<endl;
}