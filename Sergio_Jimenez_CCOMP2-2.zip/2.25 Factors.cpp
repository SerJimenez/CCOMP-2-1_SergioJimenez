#include <iostream>

using namespace std;

int main()
  {
 int numero1, numero2;

 cout << "Ingrese 2 numeros enteros: ";
 cin >> numero1 >> numero2;

 if ( numero1 % numero2 == 0 )
 cout << numero1 << "Es multiplo de" << numero2 << endl;

 if ( numero1 % numero2 != 0 )
 cout << numero1 << "No es multiplo de" << numero2 << endl;

 return 0;
 }