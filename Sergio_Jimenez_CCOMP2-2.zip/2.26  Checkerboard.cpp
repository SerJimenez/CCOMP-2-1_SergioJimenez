#include <iostream>
    
    using std::cout;
    
    using std::cin;
    
    using std::endl;

int main()
{
 
 cout<<"* * * * * * * * "<<endl;
 cout<<" * * * * * * * *"<<endl;
 cout<<"* * * * * * * * "<<endl;
 cout<<" * * * * * * * *"<<endl;
 cout<<"* * * * * * * * "<<endl;
 cout<<" * * * * * * * *"<<endl;
 cout<<"* * * * * * * * "<<endl;
 cout<<" * * * * * * * *"<<endl;
 
 return 0;
}
